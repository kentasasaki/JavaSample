package test_interface;

public interface Character {

	//メソッド　攻撃
	public abstract int attack();

	//メソッド　防御
	public abstract int Defanse();

	//メソッド　逃走
	public abstract void run();

}
