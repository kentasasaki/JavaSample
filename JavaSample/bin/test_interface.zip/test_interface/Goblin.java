package test_interface;

public class Goblin extends Monster{

	String name;

	//コンストラクタ
	public Goblin(String name) {
		this.name = name;
		this.hp = 100;
		this.attackPower = 10;
	}

	public int attack(Hero h) {
		h.hp -= this.attackPower;
		return this.attackPower;
	}

	public int Defanse(Hero h) {
		this.hp -= h.attackPower / 2;
		return h.attackPower / 2;

	}
}
