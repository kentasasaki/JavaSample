package test_interface;

public abstract class Monster implements Character {

	String name;
	int hp;
	int attackPower;

	//オーバーライド
	public void run() {
		System.out.println(this.name + "は逃げた！");
	}
}
