package test_interface;

public abstract class Human implements Character {

	String name;
	int hp;
	int attackPower;

	public abstract int attack(Goblin g);
	public abstract int Defanse(Goblin g);
	//オーバーライド
	public void run() {
		System.out.println(this.name + "は逃げた！");
	}
}
