package test_interface;

public  class Hero extends Human {

	public Hero(String name) {
		this.name = name;
		this.hp = 100;
		this.attackPower = 30;
	}
	@Override
	public int attack(Goblin goblin) {
		goblin.hp -= this.attackPower;
		return this.attackPower;
	}
	@Override
	public int Defanse(Goblin goblin) {
		this.hp -= goblin.attackPower / 2;
		return goblin.attackPower / 2;

	}
}
