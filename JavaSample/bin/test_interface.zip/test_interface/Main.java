package test_interface;

import java.util.Random;

public class Main {

	public static void main(String[] args) {
		//interfaceを継承したクラス
		//インスタンス化
		Hero h = new Hero("勇者");
		Goblin g = new Goblin("ごぶりん");

		Random random = new Random();
		int randomValue;
		int HeroAction;
		int GobulinAction;
		int Battalcommand = 0;
		int damage = 0;

		//戦闘回数
		for (int i = 0; i <= 4; i++) {
			//どんな行動をとるか
			//１＝攻撃　2＝防御
			HeroAction = random.nextInt(2) + 1;
			GobulinAction = random.nextInt(2) + 1;

			//お互い攻撃
			if (HeroAction == 1 && GobulinAction == 1) {
				Battalcommand = 1;
			}
			//勇者防御成功
			if (HeroAction == 2 && GobulinAction == 1) {
				Battalcommand = 2;
			}
			//ごぶりん/防御成功
			if (HeroAction == 1 && GobulinAction == 2) {
				Battalcommand = 3;
			}

			//防御×防御のため失敗
			if (HeroAction == 2 && GobulinAction == 2) {
				Battalcommand = 4;
			}

			System.out.println("【" + (i + 1) + "ターン目】");

			switch (Battalcommand) {
			case 1:
				randomValue = random.nextInt(2) + 1;
				//勇者→ごぶりんの順で攻撃
				if (randomValue == 1) {
					damage = h.attack(g);
					System.out.println(h.name + "の攻撃。" + damage + "のダメージ！");

					damage = g.attack(h);
					System.out.println(g.name + "の攻撃。" + damage + "のダメージ！");

				} else {
					damage = g.attack(h);
					System.out.println(g.name + "の攻撃。" + damage + "のダメージ！");

					damage = h.attack(g);
					System.out.println(h.name + "の攻撃。" + damage + "のダメージ！");

				}
				break;
			case 2:
				h.Defanse(g);
				System.out.println(g.name + "の攻撃。" +h.name+"はガードした！" +damage + "のダメージ！");

				break;
			case 3:
				g.Defanse(h);
				System.out.println(h.name + "の攻撃。" +g.name+"はガードした！" +damage + "のダメージ！");
				break;

			case 4:
				System.out.println("どちらも防御。防御失敗！");
				break;

			}
			System.out.println(h.name + "のHPは" + h.Hp + "です");
			System.out.println(g.name + "のHPは" + g.Hp + "です");

		}

	}

}
